#while loop

i = 1

while i <= 5
    puts i
    i += 1
end