puts "Enter your name: "

name = gets.chomp #usi line khatar

puts "Hello #{name}, How are you"