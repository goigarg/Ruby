friends = []

friends.push("Ansh")

friends.push("Goi")

friends.push("Pankaj")

friends.pop

puts friends

puts "\n"

puts friends.reverse

puts "\n"

puts friends.include? "Ansh"
