#Number

puts 2 * 3

puts 2 ** 3

puts 10 % 3

puts 1 + 2 * 3

puts 10/2

num = 10

puts num += 10

x = 55.49

puts x.round() #round off number