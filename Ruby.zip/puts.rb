a = 5

b = "HELLO WORLD"



puts "Number is #{a}"

puts "fdlaskj" + b

x = true

puts x
