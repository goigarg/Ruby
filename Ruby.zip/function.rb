def add(x, y=99)
    return x+y
end

sum = add(2, 3)

puts sum