x = "Hello"

puts x.length

puts x[0]

puts x.include? "llo"

puts x.include? "z"

puts x[2,2]

