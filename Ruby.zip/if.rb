ansh = true

goi = false

if ansh or goi
    puts "One is smart"
elsif ansh and goi
    puts "Both are smart"
else
    puts "FAILED"
end


if 1>3
    puts "Num is greater"
end

if "a" > "b"
    puts "true"
end


if 1 == 2
    puts "True"
end