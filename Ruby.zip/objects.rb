grade = {
    "Goi" => "50%",
    "Ansh" => "60%",
    :pankaj => "100%",
    3 => "67%"
}

puts grade["Goi"]

puts grade[3]

puts grade[:pankaj]