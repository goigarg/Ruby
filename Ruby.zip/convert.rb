a = 3.14

puts a.to_i #convert to int

puts a.to_f #covert to float

puts 3.to_s #convert to string


puts 50 + "100".to_i

puts 50.to_s + 100.to_s

