num = [4, 8, "fifteen", 16, 23, 42.0]

puts num[0]

puts num[1]

puts "First Number is #{num[1]} Second Number is #{num[2]}"

puts num[-1]

puts num[2,3]
puts "\n \n"
puts num[2..4]

puts num.length