

puts Math.sqrt(144).to_i #square root

puts Math.log(10)