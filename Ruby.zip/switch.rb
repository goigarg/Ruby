#Switch Statement

grade = "C"

case grade
    when "A"
        puts "Pass"
    when "B"
        puts "Fail"
    else
        puts "Default"
end