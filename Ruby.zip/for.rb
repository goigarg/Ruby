begin
#for loop
for i in 0..5
    puts i
end

puts "\n"

5.times do |i|
    puts i
end

array = [52,8,7,6,5,8]


puts "\n"

for item in array 
    puts item
end


array = [52,8,7,6,5,8]


array.each do |item|
    puts item
end